<?php include_once('./inc/header.php')?>
 <!-- START SECTION BANNER -->



 <div class="banner_section slide_medium shop_banner_slider staggered-animation-wrap">
     <div id="carouselExampleControls" class="carousel slide carousel-fade light_arrow" data-ride="carousel">
         <div class="carousel-inner">
             <div class="carousel-item background_bg active background_bg_one" >
                 <img src="assets/images/banner01.jpg" alt=""></img>
                 <div class="banner_slide_content banner_content_inner">
                	 <div class="container">
                    	 <div class="row">
                             <div class="col-lg-12 col-12">
                                 <div class="banner_content overflow-hidden" style="text-align: center;">
                                     <h2 class="staggered-animation" data-animation="slideInLeft" data-animation-delay="0.5s">First Pair Free</h2>
                                     <h5 class="mb-3 mb-sm-4 staggered-animation font-weight-light" data-animation="slideInLeft" data-animation-delay="1s">Sunglasses fashion translucent sunglasses star </h5>
                                     <a class="btn btn-fill-out staggered-animation text-uppercase" href="#" data-animation="slideInLeft" data-animation-delay="1.5s">Shop Now </a>
                                 </div>
                             </div>
                    	 </div>
                     </div>
                 </div>
             </div>
             <div class="carousel-item background_bg background_bg_one" >
                 <img src="assets/images/banner18.jpg"></img>
                 <div class="banner_slide_content banner_content_inner">
                	 <div class="container">
                    	 <div class="row">
                    		 <div class="col-lg-12 col-12">
                                 <div class="banner_content overflow-hidden" style="text-align: center;">
                                     <h2 class="staggered-animation" data-animation="slideInLeft" data-animation-delay="0.5s">First Pair Free </h2>
                                     <h5 class="mb-3 mb-sm-4 staggered-animation font-weight-light" data-animation="slideInLeft" data-animation-delay="1s"><span class="text_default">Sunglasses fashion translucent sunglasses star </h5>
                                     <a class="btn btn-fill-out staggered-animation text-uppercase" href="#" data-animation="slideInLeft" data-animation-delay="1.5s">Shop Now </a>
                                 </div>
                             </div>
                    	 </div>	
                     </div>
                 </div>
             </div>
             <div class="carousel-item background_bg background_bg_one" >
             <img src="assets/images/banner17.jpg"></img>
                 <div class="banner_slide_content banner_content_inner">
                	 <div class="container">
                    	 <div class="row">
                    		 <div class="col-lg-12 col-12">
                                 <div class="banner_content overflow-hidden" style="text-align: center;">
                                     <h2 class="staggered-animation" data-animation="slideInLeft" data-animation-delay="0.5s">First Pair Free </h2>
                                     <h5 class="mb-3 mb-sm-4 staggered-animation font-weight-light" data-animation="slideInLeft" data-animation-delay="1s">Sunglasses fashion translucent sunglasses star</h5>
                                     <a class="btn btn-fill-out staggered-animation text-uppercase" href="#" data-animation="slideInLeft" data-animation-delay="1.5s">Shop Now </a>
                                 </div>
                             </div>
                    	 </div>
                     </div>
                 </div>
             </div>
         </div>
         <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev"><i class="ion-chevron-left"></i></a>
         <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next"><i class="ion-chevron-right"></i></a>
     </div>
 </div>




 <!-- END SECTION BANNER -->

 <!-- END MAIN CONTENT -->
 <div class="main_content">




 <div class="section pb_20 small_pt">
	 <div class="custom-container">
    	 <div class="row justify-content-center">
        	 <div class="col-md-4 col-sm-6">
            	 <div class="sale-banner mb-3 mb-md-4">
                	 <a class="hover_effect1" href="category.php">
                		 <img src="assets/images/shop_banner_img7.jpg" alt="shop_banner_img7">
                     </a>
                 </div>
             </div>
             <!-- <div class="col-md-4">
            	 <div class="sale-banner mb-3 mb-md-4">
                	 <a class="hover_effect1" href="#">
                		 <img src="assets/images/shop_banner_img8.jpg" alt="shop_banner_img8">
                     </a>
                 </div>
             </div> -->
             <div class="col-md-4 col-sm-6">
            	 <div class="sale-banner mb-3 mb-md-4">
                	 <a class="hover_effect1" href="category.php">
                		 <img src="assets/images/shop_banner_img9.jpg" alt="shop_banner_img9">
                     </a>
                 </div>
             </div>
         </div>
     </div>
 </div>

 <!-- START SECTION SHOP -->
 <div class="section small_pt pb-0 ">
	 <div class="custom-container">
    	 <div class="row">
        	 <!-- <div class="col-xl-3 d-none d-xl-block">
            	 <div class="sale-banner">
                	 <a class="hover_effect1" href="#">
                		 <img src="assets/images/shop_banner_img6.jpg" alt="shop_banner_img6" />
                     </a>
                 </div>
             </div> -->
        	 <div class="col-xl-12">
                 <div class="row">
                     <div class="col-12">
                         <div class="heading_tab_header">
                             <div class="heading_s2">
                                 <h4>Exclusive Products </h4>
                             </div>
                             <div class="tab-style2">
                                 <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#tabmenubar" aria-expanded="false"> 
                                     <span class="ion-android-menu"></span>
                                 </button>
                                 <ul class="nav nav-tabs justify-content-center justify-content-md-end" id="tabmenubar" role="tablist">
                                     <li class="nav-item">
                                         <a class="nav-link active" id="arrival-tab" data-toggle="tab" href="#arrival" role="tab" aria-controls="arrival" aria-selected="true">New Arrival </a>
                                     </li>
                                     <li class="nav-item">
                                         <a class="nav-link" id="sellers-tab" data-toggle="tab" href="#sellers" role="tab" aria-controls="sellers" aria-selected="false">Best Sellers </a>
                                     </li>
                                     <li class="nav-item">
                                         <a class="nav-link" id="featured-tab" data-toggle="tab" href="#featured" role="tab" aria-controls="featured" aria-selected="false">Featured </a>
                                     </li>
                                     <li class="nav-item">
                                         <a class="nav-link" id="special-tab" data-toggle="tab" href="#special" role="tab" aria-controls="special" aria-selected="false">Special Offer
                                        </a>
                                     </li>
                                 </ul>
                             </div>
                         </div>
                     </div>
                 </div>
                 <div class="row">
                     <div class="col-12">
                         <div class="tab_slider">
                             <div class="tab-pane fade show active" id="arrival" role="tabpanel" aria-labelledby="arrival-tab">
                                 <div class="product_slider carousel_slider owl-carousel owl-theme dot_style1" data-loop="true" data-margin="20" data-responsive='{"0":{"items": "1"}, "481":{"items": "2"}, "768":{"items": "3"}, "991":{"items": "5"}}'>
                                     <div class="item">
                                         <div class="product_wrap">
                                             <div class="product_img">
                                                 <a href="shop-product-detail.php">
                                                     <img src="assets/images/el_img1.jpg" alt="el_img1" />
                                                     <img class="product_hover_img" src="assets/images/el_hover_img1.jpg" alt="el_hover_img1" />
                                                 </a>
                                                 <div class="product_action_box">
                                                     <ul class="list_none pr_action_btn">
                                                         <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                                         <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                                         <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                                         <li><a href="#"><i class="icon-heart"></i></a></li>
                                                     </ul>
                                                 </div>
                                             </div>
                                             <div class="product_info">
                                                 <h6 class="product_title"><a href="shop-product-detail.php">Red & Black Headphone </a></h6>
                                                 <div class="product_price">
                                                     <span class="price">$45.00 </span>
                                                     <del>$55.25 </del>
                                                     <div class="on_sale">
                                                         <span>35% Off </span>
                                                     </div>
                                                 </div>
                                                 <div class="rating_wrap">
                                                     <div class="rating">
                                                         <div class="product_rate" style="width:80%"></div>
                                                     </div>
                                                     <span class="rating_num">(21) </span>
                                                 </div>
                                                 <div class="pr_desc">
                                                     <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="item">
                                         <div class="product_wrap">
                                             <div class="product_img">
                                                 <a href="shop-product-detail.php">
                                                     <img src="assets/images/el_img2.jpg" alt="el_img2" />
                                                     <img class="product_hover_img" src="assets/images/el_hover_img2.jpg" alt="el_hover_img2" />
                                                 </a>
                                                 <div class="product_action_box">
                                                     <ul class="list_none pr_action_btn">
                                                         <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                                         <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                                         <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                                         <li><a href="#"><i class="icon-heart"></i></a></li>
                                                     </ul>
                                                 </div>
                                             </div>
                                             <div class="product_info">
                                                 <h6 class="product_title"><a href="shop-product-detail.php">Smart Watch External </a></h6>
                                                 <div class="product_price">
                                                     <span class="price">$55.00 </span>
                                                     <del>$95.00 </del>
                                                     <div class="on_sale">
                                                         <span>25% Off </span>
                                                     </div>
                                                 </div>
                                                 <div class="rating_wrap">
                                                     <div class="rating">
                                                         <div class="product_rate" style="width:68%"></div>
                                                     </div>
                                                     <span class="rating_num">(15) </span>
                                                 </div>
                                                 <div class="pr_desc">
                                                     <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="item">
                                         <div class="product_wrap">
                                             <span class="pr_flash">New </span>
                                             <div class="product_img">
                                                 <a href="shop-product-detail.php">
                                                     <img src="assets/images/el_img3.jpg" alt="el_img3" />
                                                     <img class="product_hover_img" src="assets/images/el_hover_img3.jpg" alt="el_hover_img3" />
                                                 </a>
                                                 <div class="product_action_box">
                                                     <ul class="list_none pr_action_btn">
                                                         <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                                         <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                                         <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                                         <li><a href="#"><i class="icon-heart"></i></a></li>
                                                     </ul>
                                                 </div>
                                             </div>
                                             <div class="product_info">
                                                 <h6 class="product_title"><a href="shop-product-detail.php">Nikon HD camera </a></h6>
                                                 <div class="product_price">
                                                     <span class="price">$68.00 </span>
                                                     <del>$99.00 </del>
                                                 </div>
                                                 <div class="rating_wrap">
                                                     <div class="rating">
                                                         <div class="product_rate" style="width:87%"></div>
                                                     </div>
                                                     <span class="rating_num">(25) </span>
                                                 </div>
                                                 <div class="pr_desc">
                                                     <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="item">
                                         <div class="product_wrap">
                                             <div class="product_img">
                                                 <a href="shop-product-detail.php">
                                                     <img src="assets/images/el_img4.jpg" alt="el_img4" />
                                                     <img class="product_hover_img" src="assets/images/el_hover_img4.jpg" alt="el_hover_img4" />
                                                 </a>
                                                 <div class="product_action_box">
                                                     <ul class="list_none pr_action_btn">
                                                         <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                                         <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                                         <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                                         <li><a href="#"><i class="icon-heart"></i></a></li>
                                                     </ul>
                                                 </div>
                                             </div>
                                             <div class="product_info">
                                                 <h6 class="product_title"><a href="shop-product-detail.php">Audio Equipment </a></h6>
                                                 <div class="product_price">
                                                     <span class="price">$69.00 </span>
                                                     <del>$89.00 </del>
                                                     <div class="on_sale">
                                                         <span>20% Off </span>
                                                     </div>
                                                 </div>
                                                 <div class="rating_wrap">
                                                     <div class="rating">
                                                         <div class="product_rate" style="width:70%"></div>
                                                     </div>
                                                     <span class="rating_num">(22) </span>
                                                 </div>
                                                 <div class="pr_desc">
                                                     <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="item">
                                         <div class="product_wrap">
                                             <div class="product_img">
                                                 <a href="shop-product-detail.php">
                                                     <img src="assets/images/el_img5.jpg" alt="el_img5" />
                                                     <img class="product_hover_img" src="assets/images/el_hover_img5.jpg" alt="el_hover_img5" />
                                                 </a>
                                                 <div class="product_action_box">
                                                     <ul class="list_none pr_action_btn">
                                                         <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                                         <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                                         <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                                         <li><a href="#"><i class="icon-heart"></i></a></li>
                                                     </ul>
                                                 </div>
                                             </div>
                                             <div class="product_info">
                                                 <h6 class="product_title"><a href="shop-product-detail.php">Smart Televisions </a></h6>
                                                 <div class="product_price">
                                                     <span class="price">$45.00 </span>
                                                     <del>$55.25 </del>
                                                     <div class="on_sale">
                                                         <span>35% Off </span>
                                                     </div>
                                                 </div>
                                                 <div class="rating_wrap">
                                                     <div class="rating">
                                                         <div class="product_rate" style="width:80%"></div>
                                                     </div>
                                                     <span class="rating_num">(21) </span>
                                                 </div>
                                                 <div class="pr_desc">
                                                     <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="item">
                                         <div class="product_wrap">
                                             <span class="pr_flash bg-danger">Hot </span>
                                             <div class="product_img">
                                                 <a href="shop-product-detail.php">
                                                     <img src="assets/images/el_img6.jpg" alt="el_img6" />
                                                     <img class="product_hover_img" src="assets/images/el_hover_img6.jpg" alt="el_hover_img6" />
                                                 </a>
                                                 <div class="product_action_box">
                                                     <ul class="list_none pr_action_btn">
                                                         <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                                         <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                                         <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                                         <li><a href="#"><i class="icon-heart"></i></a></li>
                                                     </ul>
                                                 </div>
                                             </div>
                                             <div class="product_info">
                                                 <h6 class="product_title"><a href="shop-product-detail.php">Samsung Smart Phone </a></h6>
                                                 <div class="product_price">
                                                     <span class="price">$55.00 </span>
                                                     <del>$95.00 </del>
                                                     <div class="on_sale">
                                                         <span>25% Off </span>
                                                     </div>
                                                 </div>
                                                 <div class="rating_wrap">
                                                     <div class="rating">
                                                         <div class="product_rate" style="width:68%"></div>
                                                     </div>
                                                     <span class="rating_num">(15) </span>
                                                 </div>
                                                 <div class="pr_desc">
                                                     <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                 </div>
                             </div>
                             <div class="tab-pane fade" id="sellers" role="tabpanel" aria-labelledby="sellers-tab">
                                 <div class="product_slider carousel_slider owl-carousel owl-theme dot_style1" data-loop="true" data-margin="20" data-responsive='{"0":{"items": "1"}, "481":{"items": "2"}, "768":{"items": "3"}, "991":{"items": "5"}}'>
                                     <div class="item">
                                         <div class="product_wrap">
                                             <div class="product_img">
                                                 <a href="shop-product-detail.php">
                                                     <img src="assets/images/el_img7.jpg" alt="el_img7" />
                                                     <img class="product_hover_img" src="assets/images/el_hover_img7.jpg" alt="el_hover_img7" />
                                                 </a>
                                                 <div class="product_action_box">
                                                     <ul class="list_none pr_action_btn">
                                                         <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                                         <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                                         <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                                         <li><a href="#"><i class="icon-heart"></i></a></li>
                                                     </ul>
                                                 </div>
                                             </div>
                                             <div class="product_info">
                                                 <h6 class="product_title"><a href="shop-product-detail.php">Audio Theaters </a></h6>
                                                 <div class="product_price">
                                                     <span class="price">$45.00 </span>
                                                     <del>$55.25 </del>
                                                     <div class="on_sale">
                                                         <span>35% Off </span>
                                                     </div>
                                                 </div>
                                                 <div class="rating_wrap">
                                                     <div class="rating">
                                                         <div class="product_rate" style="width:80%"></div>
                                                     </div>
                                                     <span class="rating_num">(21) </span>
                                                 </div>
                                                 <div class="pr_desc">
                                                     <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="item">
                                         <div class="product_wrap">
                                             <span class="pr_flash bg-danger">Hot </span>
                                             <div class="product_img">
                                                 <a href="shop-product-detail.php">
                                                     <img src="assets/images/el_img8.jpg" alt="el_img8" />
                                                     <img class="product_hover_img" src="assets/images/el_hover_img8.jpg" alt="el_hover_img8" />
                                                 </a>
                                                 <div class="product_action_box">
                                                     <ul class="list_none pr_action_btn">
                                                         <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                                         <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                                         <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                                         <li><a href="#"><i class="icon-heart"></i></a></li>
                                                     </ul>
                                                 </div>
                                             </div>
                                             <div class="product_info">
                                                 <h6 class="product_title"><a href="shop-product-detail.php">Surveillance camera </a></h6>
                                                 <div class="product_price">
                                                     <span class="price">$55.00 </span>
                                                     <del>$95.00 </del>
                                                     <div class="on_sale">
                                                         <span>25% Off </span>
                                                     </div>
                                                 </div>
                                                 <div class="rating_wrap">
                                                     <div class="rating">
                                                         <div class="product_rate" style="width:68%"></div>
                                                     </div>
                                                     <span class="rating_num">(15) </span>
                                                 </div>
                                                 <div class="pr_desc">
                                                     <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="item">
                                         <div class="product_wrap">
                                             <div class="product_img">
                                                 <a href="shop-product-detail.php">
                                                     <img src="assets/images/el_img9.jpg" alt="el_img9" />
                                                     <img class="product_hover_img" src="assets/images/el_hover_img9.jpg" alt="el_hover_img9" />
                                                 </a>
                                                 <div class="product_action_box">
                                                     <ul class="list_none pr_action_btn">
                                                         <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                                         <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                                         <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                                         <li><a href="#"><i class="icon-heart"></i></a></li>
                                                     </ul>
                                                 </div>
                                             </div>
                                             <div class="product_info">
                                                 <h6 class="product_title"><a href="shop-product-detail.php">oppo Reno3 Pro </a></h6>
                                                 <div class="product_price">
                                                     <span class="price">$68.00 </span>
                                                     <del>$99.00 </del>
                                                     <div class="on_sale">
                                                         <span>20% Off </span>
                                                     </div>
                                                 </div>
                                                 <div class="rating_wrap">
                                                     <div class="rating">
                                                         <div class="product_rate" style="width:87%"></div>
                                                     </div>
                                                     <span class="rating_num">(25) </span>
                                                 </div>
                                                 <div class="pr_desc">
                                                     <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="item">
                                         <div class="product_wrap">
                                             <span class="pr_flash bg-success">Sale </span>
                                             <div class="product_img">
                                                 <a href="shop-product-detail.php">
                                                     <img src="assets/images/el_img10.jpg" alt="el_img10" />
                                                     <img class="product_hover_img" src="assets/images/el_hover_img10.jpg" alt="el_hover_img10" />
                                                 </a>
                                                 <div class="product_action_box">
                                                     <ul class="list_none pr_action_btn">
                                                         <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                                         <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                                         <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                                         <li><a href="#"><i class="icon-heart"></i></a></li>
                                                     </ul>
                                                 </div>
                                             </div>
                                             <div class="product_info">
                                                 <h6 class="product_title"><a href="shop-product-detail.php">classical Headphone </a></h6>
                                                 <div class="product_price">
                                                     <span class="price">$68.00 </span>
                                                     <del>$99.00 </del>
                                                     <div class="on_sale">
                                                         <span>20% Off </span>
                                                     </div>
                                                 </div>
                                                 <div class="rating_wrap">
                                                     <div class="rating">
                                                         <div class="product_rate" style="width:87%"></div>
                                                     </div>
                                                     <span class="rating_num">(25) </span>
                                                 </div>
                                                 <div class="pr_desc">
                                                     <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="item">
                                         <div class="product_wrap">
                                             <div class="product_img">
                                                 <a href="shop-product-detail.php">
                                                     <img src="assets/images/el_img11.jpg" alt="el_img11" />
                                                     <img class="product_hover_img" src="assets/images/el_hover_img11.jpg" alt="el_hover_img11" />
                                                 </a>
                                                 <div class="product_action_box">
                                                     <ul class="list_none pr_action_btn">
                                                         <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                                         <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                                         <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                                         <li><a href="#"><i class="icon-heart"></i></a></li>
                                                     </ul>
                                                 </div>
                                             </div>
                                             <div class="product_info">
                                                 <h6 class="product_title"><a href="shop-product-detail.php">Basics High-Speed HDMI </a></h6>
                                                 <div class="product_price">
                                                     <span class="price">$69.00 </span>
                                                     <del>$89.00 </del>
                                                     <div class="on_sale">
                                                         <span>20% Off </span>
                                                     </div>
                                                 </div>
                                                 <div class="rating_wrap">
                                                     <div class="rating">
                                                         <div class="product_rate" style="width:70%"></div>
                                                     </div>
                                                     <span class="rating_num">(22) </span>
                                                 </div>
                                                 <div class="pr_desc">
                                                     <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="item">
                                         <div class="product_wrap">
                                             <div class="product_img">
                                                 <a href="shop-product-detail.php">
                                                     <img src="assets/images/el_img12.jpg" alt="el_img12" />
                                                     <img class="product_hover_img" src="assets/images/el_hover_img12.jpg" alt="el_hover_img12" />
                                                 </a>
                                                 <div class="product_action_box">
                                                     <ul class="list_none pr_action_btn">
                                                         <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                                         <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                                         <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                                         <li><a href="#"><i class="icon-heart"></i></a></li>
                                                     </ul>
                                                 </div>
                                             </div>
                                             <div class="product_info">
                                                 <h6 class="product_title"><a href="shop-product-detail.php">Sound Equipment for Low </a></h6>
                                                 <div class="product_price">
                                                     <span class="price">$45.00 </span>
                                                     <del>$55.25 </del>
                                                     <div class="on_sale">
                                                         <span>35% Off </span>
                                                     </div>
                                                 </div>
                                                 <div class="rating_wrap">
                                                     <div class="rating">
                                                         <div class="product_rate" style="width:80%"></div>
                                                     </div>
                                                     <span class="rating_num">(21) </span>
                                                 </div>
                                                 <div class="pr_desc">
                                                     <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                 </div>
                             </div>
                             <div class="tab-pane fade" id="featured" role="tabpanel" aria-labelledby="featured-tab">
                                 <div class="product_slider carousel_slider owl-carousel owl-theme dot_style1" data-loop="true" data-margin="20" data-responsive='{"0":{"items": "1"}, "481":{"items": "2"}, "768":{"items": "3"}, "991":{"items": "5"}}'>
                                     <div class="item">
                                         <div class="product_wrap">
                                             <span class="pr_flash bg-danger">Hot </span>
                                             <div class="product_img">
                                                 <a href="shop-product-detail.php">
                                                     <img src="assets/images/el_img8.jpg" alt="el_img8" />
                                                     <img class="product_hover_img" src="assets/images/el_hover_img8.jpg" alt="el_hover_img8" />
                                                 </a>
                                                 <div class="product_action_box">
                                                     <ul class="list_none pr_action_btn">
                                                         <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                                         <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                                         <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                                         <li><a href="#"><i class="icon-heart"></i></a></li>
                                                     </ul>
                                                 </div>
                                             </div>
                                             <div class="product_info">
                                                 <h6 class="product_title"><a href="shop-product-detail.php">Surveillance camera </a></h6>
                                                 <div class="product_price">
                                                     <span class="price">$55.00 </span>
                                                     <del>$95.00 </del>
                                                     <div class="on_sale">
                                                         <span>25% Off </span>
                                                     </div>
                                                 </div>
                                                 <div class="rating_wrap">
                                                     <div class="rating">
                                                         <div class="product_rate" style="width:68%"></div>
                                                     </div>
                                                     <span class="rating_num">(15) </span>
                                                 </div>
                                                 <div class="pr_desc">
                                                     <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="item">
                                         <div class="product_wrap">
                                             <div class="product_img">
                                                 <a href="shop-product-detail.php">
                                                     <img src="assets/images/el_img4.jpg" alt="el_img4" />
                                                     <img class="product_hover_img" src="assets/images/el_hover_img4.jpg" alt="el_hover_img4" />
                                                 </a>
                                                 <div class="product_action_box">
                                                     <ul class="list_none pr_action_btn">
                                                         <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                                         <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                                         <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                                         <li><a href="#"><i class="icon-heart"></i></a></li>
                                                     </ul>
                                                 </div>
                                             </div>
                                             <div class="product_info">
                                                 <h6 class="product_title"><a href="shop-product-detail.php">Audio Equipment </a></h6>
                                                 <div class="product_price">
                                                     <span class="price">$69.00 </span>
                                                     <del>$89.00 </del>
                                                     <div class="on_sale">
                                                         <span>20% Off </span>
                                                     </div>
                                                 </div>
                                                 <div class="rating_wrap">
                                                     <div class="rating">
                                                         <div class="product_rate" style="width:70%"></div>
                                                     </div>
                                                     <span class="rating_num">(22) </span>
                                                 </div>
                                                 <div class="pr_desc">
                                                     <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="item">
                                         <div class="product_wrap">
                                             <div class="product_img">
                                                 <a href="shop-product-detail.php">
                                                     <img src="assets/images/el_img11.jpg" alt="el_img11" />
                                                     <img class="product_hover_img" src="assets/images/el_hover_img11.jpg" alt="el_hover_img11" />
                                                 </a>
                                                 <div class="product_action_box">
                                                     <ul class="list_none pr_action_btn">
                                                         <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                                         <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                                         <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                                         <li><a href="#"><i class="icon-heart"></i></a></li>
                                                     </ul>
                                                 </div>
                                             </div>
                                             <div class="product_info">
                                                 <h6 class="product_title"><a href="shop-product-detail.php">Basics High-Speed HDMI </a></h6>
                                                 <div class="product_price">
                                                     <span class="price">$69.00 </span>
                                                     <del>$89.00 </del>
                                                     <div class="on_sale">
                                                         <span>20% Off </span>
                                                     </div>
                                                 </div>
                                                 <div class="rating_wrap">
                                                     <div class="rating">
                                                         <div class="product_rate" style="width:70%"></div>
                                                     </div>
                                                     <span class="rating_num">(22) </span>
                                                 </div>
                                                 <div class="pr_desc">
                                                     <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="item">
                                         <div class="product_wrap">
                                             <div class="product_img">
                                                 <a href="shop-product-detail.php">
                                                     <img src="assets/images/el_img1.jpg" alt="el_img1" />
                                                     <img class="product_hover_img" src="assets/images/el_hover_img1.jpg" alt="el_hover_img1" />
                                                 </a>
                                                 <div class="product_action_box">
                                                     <ul class="list_none pr_action_btn">
                                                         <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                                         <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                                         <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                                         <li><a href="#"><i class="icon-heart"></i></a></li>
                                                     </ul>
                                                 </div>
                                             </div>
                                             <div class="product_info">
                                                 <h6 class="product_title"><a href="shop-product-detail.php">Red & Black Headphone </a></h6>
                                                 <div class="product_price">
                                                     <span class="price">$45.00 </span>
                                                     <del>$55.25 </del>
                                                     <div class="on_sale">
                                                         <span>35% Off </span>
                                                     </div>
                                                 </div>
                                                 <div class="rating_wrap">
                                                     <div class="rating">
                                                         <div class="product_rate" style="width:80%"></div>
                                                     </div>
                                                     <span class="rating_num">(21) </span>
                                                 </div>
                                                 <div class="pr_desc">
                                                     <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="item">
                                         <div class="product_wrap">
                                             <div class="product_img">
                                                 <a href="shop-product-detail.php">
                                                     <img src="assets/images/el_img7.jpg" alt="el_img7" />
                                                     <img class="product_hover_img" src="assets/images/el_hover_img7.jpg" alt="el_hover_img7" />
                                                 </a>
                                                 <div class="product_action_box">
                                                     <ul class="list_none pr_action_btn">
                                                         <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                                         <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                                         <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                                         <li><a href="#"><i class="icon-heart"></i></a></li>
                                                     </ul>
                                                 </div>
                                             </div>
                                             <div class="product_info">
                                                 <h6 class="product_title"><a href="shop-product-detail.php">Audio Theaters </a></h6>
                                                 <div class="product_price">
                                                     <span class="price">$45.00 </span>
                                                     <del>$55.25 </del>
                                                     <div class="on_sale">
                                                         <span>35% Off </span>
                                                     </div>
                                                 </div>
                                                 <div class="rating_wrap">
                                                     <div class="rating">
                                                         <div class="product_rate" style="width:80%"></div>
                                                     </div>
                                                     <span class="rating_num">(21) </span>
                                                 </div>
                                                 <div class="pr_desc">
                                                     <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="item">
                                         <div class="product_wrap">
                                             <span class="pr_flash bg-danger">Hot </span>
                                             <div class="product_img">
                                                 <a href="shop-product-detail.php">
                                                     <img src="assets/images/el_img6.jpg" alt="el_img6" />
                                                     <img class="product_hover_img" src="assets/images/el_hover_img6.jpg" alt="el_hover_img6" />
                                                 </a>
                                                 <div class="product_action_box">
                                                     <ul class="list_none pr_action_btn">
                                                         <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                                         <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                                         <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                                         <li><a href="#"><i class="icon-heart"></i></a></li>
                                                     </ul>
                                                 </div>
                                             </div>
                                             <div class="product_info">
                                                 <h6 class="product_title"><a href="shop-product-detail.php">Samsung Smart Phone </a></h6>
                                                 <div class="product_price">
                                                     <span class="price">$55.00 </span>
                                                     <del>$95.00 </del>
                                                     <div class="on_sale">
                                                         <span>25% Off </span>
                                                     </div>
                                                 </div>
                                                 <div class="rating_wrap">
                                                     <div class="rating">
                                                         <div class="product_rate" style="width:68%"></div>
                                                     </div>
                                                     <span class="rating_num">(15) </span>
                                                 </div>
                                                 <div class="pr_desc">
                                                     <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                 </div>
                             </div>
                             <div class="tab-pane fade" id="special" role="tabpanel" aria-labelledby="special-tab">
                                 <div class="product_slider carousel_slider owl-carousel owl-theme dot_style1" data-loop="true" data-margin="20" data-responsive='{"0":{"items": "1"}, "481":{"items": "2"}, "768":{"items": "3"}, "991":{"items": "5"}}'>
                                     <div class="item">
                                         <div class="product_wrap">
                                             <div class="product_img">
                                                 <a href="shop-product-detail.php">
                                                     <img src="assets/images/el_img2.jpg" alt="el_img2" />
                                                     <img class="product_hover_img" src="assets/images/el_hover_img2.jpg" alt="el_hover_img2" />
                                                 </a>
                                                 <div class="product_action_box">
                                                     <ul class="list_none pr_action_btn">
                                                         <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                                         <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                                         <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                                         <li><a href="#"><i class="icon-heart"></i></a></li>
                                                     </ul>
                                                 </div>
                                             </div>
                                             <div class="product_info">
                                                 <h6 class="product_title"><a href="shop-product-detail.php">Smart Watch External </a></h6>
                                                 <div class="product_price">
                                                     <span class="price">$55.00 </span>
                                                     <del>$95.00 </del>
                                                     <div class="on_sale">
                                                         <span>25% Off </span>
                                                     </div>
                                                 </div>
                                                 <div class="rating_wrap">
                                                     <div class="rating">
                                                         <div class="product_rate" style="width:68%"></div>
                                                     </div>
                                                     <span class="rating_num">(15) </span>
                                                 </div>
                                                 <div class="pr_desc">
                                                     <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="item">
                                         <div class="product_wrap">
                                             <div class="product_img">
                                                 <a href="shop-product-detail.php">
                                                     <img src="assets/images/el_img5.jpg" alt="el_img5" />
                                                     <img class="product_hover_img" src="assets/images/el_hover_img5.jpg" alt="el_hover_img5" />
                                                 </a>
                                                 <div class="product_action_box">
                                                     <ul class="list_none pr_action_btn">
                                                         <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                                         <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                                         <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                                         <li><a href="#"><i class="icon-heart"></i></a></li>
                                                     </ul>
                                                 </div>
                                             </div>
                                             <div class="product_info">
                                                 <h6 class="product_title"><a href="shop-product-detail.php">Smart Televisions </a></h6>
                                                 <div class="product_price">
                                                     <span class="price">$45.00 </span>
                                                     <del>$55.25 </del>
                                                     <div class="on_sale">
                                                         <span>35% Off </span>
                                                     </div>
                                                 </div>
                                                 <div class="rating_wrap">
                                                     <div class="rating">
                                                         <div class="product_rate" style="width:80%"></div>
                                                     </div>
                                                     <span class="rating_num">(21) </span>
                                                 </div>
                                                 <div class="pr_desc">
                                                     <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="item">
                                         <div class="product_wrap">
                                             <div class="product_img">
                                                 <a href="shop-product-detail.php">
                                                     <img src="assets/images/el_img9.jpg" alt="el_img9" />
                                                     <img class="product_hover_img" src="assets/images/el_hover_img9.jpg" alt="el_hover_img9" />
                                                 </a>
                                                 <div class="product_action_box">
                                                     <ul class="list_none pr_action_btn">
                                                         <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                                         <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                                         <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                                         <li><a href="#"><i class="icon-heart"></i></a></li>
                                                     </ul>
                                                 </div>
                                             </div>
                                             <div class="product_info">
                                                 <h6 class="product_title"><a href="shop-product-detail.php">oppo Reno3 Pro </a></h6>
                                                 <div class="product_price">
                                                     <span class="price">$68.00 </span>
                                                     <del>$99.00 </del>
                                                     <div class="on_sale">
                                                         <span>20% Off </span>
                                                     </div>
                                                 </div>
                                                 <div class="rating_wrap">
                                                     <div class="rating">
                                                         <div class="product_rate" style="width:87%"></div>
                                                     </div>
                                                     <span class="rating_num">(25) </span>
                                                 </div>
                                                 <div class="pr_desc">
                                                     <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="item">
                                         <div class="product_wrap">
                                             <div class="product_img">
                                                 <a href="shop-product-detail.php">
                                                     <img src="assets/images/el_img7.jpg" alt="el_img7" />
                                                     <img class="product_hover_img" src="assets/images/el_hover_img7.jpg" alt="el_hover_img7" />
                                                 </a>
                                                 <div class="product_action_box">
                                                     <ul class="list_none pr_action_btn">
                                                         <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                                         <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                                         <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                                         <li><a href="#"><i class="icon-heart"></i></a></li>
                                                     </ul>
                                                 </div>
                                             </div>
                                             <div class="product_info">
                                                 <h6 class="product_title"><a href="shop-product-detail.php">Audio Theaters </a></h6>
                                                 <div class="product_price">
                                                     <span class="price">$45.00 </span>
                                                     <del>$55.25 </del>
                                                     <div class="on_sale">
                                                         <span>35% Off </span>
                                                     </div>
                                                 </div>
                                                 <div class="rating_wrap">
                                                     <div class="rating">
                                                         <div class="product_rate" style="width:80%"></div>
                                                     </div>
                                                     <span class="rating_num">(21) </span>
                                                 </div>
                                                 <div class="pr_desc">
                                                     <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="item">
                                         <div class="product_wrap">
                                             <div class="product_img">
                                                 <a href="shop-product-detail.php">
                                                     <img src="assets/images/el_img5.jpg" alt="el_img5" />
                                                     <img class="product_hover_img" src="assets/images/el_hover_img5.jpg" alt="el_hover_img5" />
                                                 </a>
                                                 <div class="product_action_box">
                                                     <ul class="list_none pr_action_btn">
                                                         <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                                         <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                                         <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                                         <li><a href="#"><i class="icon-heart"></i></a></li>
                                                     </ul>
                                                 </div>
                                             </div>
                                             <div class="product_info">
                                                 <h6 class="product_title"><a href="shop-product-detail.php">Smart Televisions </a></h6>
                                                 <div class="product_price">
                                                     <span class="price">$45.00 </span>
                                                     <del>$55.25 </del>
                                                     <div class="on_sale">
                                                         <span>35% Off </span>
                                                     </div>
                                                 </div>
                                                 <div class="rating_wrap">
                                                     <div class="rating">
                                                         <div class="product_rate" style="width:80%"></div>
                                                     </div>
                                                     <span class="rating_num">(21) </span>
                                                 </div>
                                                 <div class="pr_desc">
                                                     <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="item">
                                         <div class="product_wrap">
                                             <div class="product_img">
                                                 <a href="shop-product-detail.php">
                                                     <img src="assets/images/el_img12.jpg" alt="el_img12" />
                                                     <img class="product_hover_img" src="assets/images/el_hover_img12.jpg" alt="el_hover_img12" />
                                                 </a>
                                                 <div class="product_action_box">
                                                     <ul class="list_none pr_action_btn">
                                                         <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                                         <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                                         <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                                         <li><a href="#"><i class="icon-heart"></i></a></li>
                                                     </ul>
                                                 </div>
                                             </div>
                                             <div class="product_info">
                                                 <h6 class="product_title"><a href="shop-product-detail.php">Sound Equipment for Low </a></h6>
                                                 <div class="product_price">
                                                     <span class="price">$45.00 </span>
                                                     <del>$55.25 </del>
                                                     <div class="on_sale">
                                                         <span>35% Off </span>
                                                     </div>
                                                 </div>
                                                 <div class="rating_wrap">
                                                     <div class="rating">
                                                         <div class="product_rate" style="width:80%"></div>
                                                     </div>
                                                     <span class="rating_num">(21) </span>
                                                 </div>
                                                 <div class="pr_desc">
                                                     <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
        	 </div>
         </div>
     </div>
 </div>
 <!-- END SECTION SHOP -->

 <!-- START SECTION SHOP -->
 <div class="section small_pt pb-0 m_bootm">
	 <div class="custom-container">
    	 <div class="row">
            <div class="col-md-12">
                <div class="heading_s4 text-center">
                    <h2> Our Top Products </h2>
                </div>
                <p class="text-center leads">Lorem ipsum dolor sit , consectetur adipiscing elit. Phasellus massa enim Nullam nunc . </p>
            </div>
        	 <div class="col-xl-9">
                 <div class="row">
                     <div class="col-6 col-sm-6 col-md-4 col-lg-3">
                        <div class="product_wrap">
                            <div class="product_img">
                                <a href="shop-product-detail.php">
                                    <img src="assets/images/el_img1.jpg" alt="el_img1" />
                                    <img class="product_hover_img" src="assets/images/el_hover_img1.jpg" alt="el_hover_img1" />
                                </a>
                                <div class="product_action_box">
                                    <ul class="list_none pr_action_btn">
                                        <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                        <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                        <!-- <a title="Quick View" class="quickview" href="#">  ddd</a> -->
                                        <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                        <li><a href="#"><i class="icon-heart"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_info">
                                <h6 class="product_title"><a href="shop-product-detail.php">Red & Black Headphone </a></h6>
                                <div class="product_price">
                                    <span class="price">$45.00 </span>
                                    <del>$55.25 </del>
                                    <div class="on_sale">
                                        <span>35% Off </span>
                                    </div>
                                </div>
                                <div class="rating_wrap">
                                    <div class="rating">
                                        <div class="product_rate" style="width:80%"></div>
                                    </div>
                                    <span class="rating_num">(21) </span>
                                </div>
                                <div class="pr_desc">
                                    <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                </div>
                            </div>
                        </div>
                     </div>
                     <div class="col-6 col-sm-6 col-md-4 col-lg-3">
                        <div class="product_wrap">
                            <div class="product_img">
                                <a href="shop-product-detail.php">
                                    <img src="assets/images/el_img1.jpg" alt="el_img1" />
                                    <img class="product_hover_img" src="assets/images/el_hover_img1.jpg" alt="el_hover_img1" />
                                </a>
                                <div class="product_action_box">
                                    <ul class="list_none pr_action_btn">
                                        <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                        <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                        <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                        <li><a href="#"><i class="icon-heart"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_info">
                                <h6 class="product_title"><a href="shop-product-detail.php">Red & Black Headphone </a></h6>
                                <div class="product_price">
                                    <span class="price">$45.00 </span>
                                    <del>$55.25 </del>
                                    <div class="on_sale">
                                        <span>35% Off </span>
                                    </div>
                                </div>
                                <div class="rating_wrap">
                                    <div class="rating">
                                        <div class="product_rate" style="width:80%"></div>
                                    </div>
                                    <span class="rating_num">(21) </span>
                                </div>
                                <div class="pr_desc">
                                    <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                </div>
                            </div>
                        </div>
                     </div>

                     <div class="col-6 col-sm-6 col-md-4 col-lg-3">
                        <div class="product_wrap">
                            <div class="product_img">
                                <a href="shop-product-detail.php">
                                    <img src="assets/images/el_img1.jpg" alt="el_img1" />
                                    <img class="product_hover_img" src="assets/images/el_hover_img1.jpg" alt="el_hover_img1" />
                                </a>
                                <div class="product_action_box">
                                    <ul class="list_none pr_action_btn">
                                        <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                        <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                        <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                        <li><a href="#"><i class="icon-heart"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_info">
                                <h6 class="product_title"><a href="shop-product-detail.php">Red & Black Headphone </a></h6>
                                <div class="product_price">
                                    <span class="price">$45.00 </span>
                                    <del>$55.25 </del>
                                    <div class="on_sale">
                                        <span>35% Off </span>
                                    </div>
                                </div>
                                <div class="rating_wrap">
                                    <div class="rating">
                                        <div class="product_rate" style="width:80%"></div>
                                    </div>
                                    <span class="rating_num">(21) </span>
                                </div>
                                <div class="pr_desc">
                                    <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                </div>
                            </div>
                        </div>
                     </div>

                     <div class="col-6 col-sm-6 col-md-4 col-lg-3">
                        <div class="product_wrap">
                            <div class="product_img">
                                <a href="shop-product-detail.php">
                                    <img src="assets/images/el_img1.jpg" alt="el_img1" />
                                    <img class="product_hover_img" src="assets/images/el_hover_img1.jpg" alt="el_hover_img1" />
                                </a>
                                <div class="product_action_box">
                                    <ul class="list_none pr_action_btn">
                                        <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                        <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                        <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                        <li><a href="#"><i class="icon-heart"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_info">
                                <h6 class="product_title"><a href="shop-product-detail.php">Red & Black Headphone </a></h6>
                                <div class="product_price">
                                    <span class="price">$45.00 </span>
                                    <del>$55.25 </del>
                                    <div class="on_sale">
                                        <span>35% Off </span>
                                    </div>
                                </div>
                                <div class="rating_wrap">
                                    <div class="rating">
                                        <div class="product_rate" style="width:80%"></div>
                                    </div>
                                    <span class="rating_num">(21) </span>
                                </div>
                                <div class="pr_desc">
                                    <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                </div>
                            </div>
                        </div>
                     </div>

                     <div class="col-6 col-sm-6 col-md-4 col-lg-3">
                        <div class="product_wrap">
                            <div class="product_img">
                                <a href="shop-product-detail.php">
                                    <img src="assets/images/el_img1.jpg" alt="el_img1" />
                                    <img class="product_hover_img" src="assets/images/el_hover_img1.jpg" alt="el_hover_img1" />
                                </a>
                                <div class="product_action_box">
                                    <ul class="list_none pr_action_btn">
                                        <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                        <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                        <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                        <li><a href="#"><i class="icon-heart"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_info">
                                <h6 class="product_title"><a href="shop-product-detail.php">Red & Black Headphone </a></h6>
                                <div class="product_price">
                                    <span class="price">$45.00 </span>
                                    <del>$55.25 </del>
                                    <div class="on_sale">
                                        <span>35% Off </span>
                                    </div>
                                </div>
                                <div class="rating_wrap">
                                    <div class="rating">
                                        <div class="product_rate" style="width:80%"></div>
                                    </div>
                                    <span class="rating_num">(21) </span>
                                </div>
                                <div class="pr_desc">
                                    <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                </div>
                            </div>
                        </div>
                     </div>

                     <div class="col-6 col-sm-6 col-md-4 col-lg-3">
                        <div class="product_wrap">
                            <div class="product_img">
                                <a href="shop-product-detail.php">
                                    <img src="assets/images/el_img1.jpg" alt="el_img1" />
                                    <img class="product_hover_img" src="assets/images/el_hover_img1.jpg" alt="el_hover_img1" />
                                </a>
                                <div class="product_action_box">
                                    <ul class="list_none pr_action_btn">
                                        <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                        <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                        <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                        <li><a href="#"><i class="icon-heart"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_info">
                                <h6 class="product_title"><a href="shop-product-detail.php">Red & Black Headphone </a></h6>
                                <div class="product_price">
                                    <span class="price">$45.00 </span>
                                    <del>$55.25 </del>
                                    <div class="on_sale">
                                        <span>35% Off </span>
                                    </div>
                                </div>
                                <div class="rating_wrap">
                                    <div class="rating">
                                        <div class="product_rate" style="width:80%"></div>
                                    </div>
                                    <span class="rating_num">(21) </span>
                                </div>
                                <div class="pr_desc">
                                    <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                </div>
                            </div>
                        </div>
                     </div>

                     <div class="col-6 col-sm-6 col-md-4 col-lg-3">
                        <div class="product_wrap">
                            <div class="product_img">
                                <a href="shop-product-detail.php">
                                    <img src="assets/images/el_img1.jpg" alt="el_img1" />
                                    <img class="product_hover_img" src="assets/images/el_hover_img1.jpg" alt="el_hover_img1" />
                                </a>
                                <div class="product_action_box">
                                    <ul class="list_none pr_action_btn">
                                        <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                        <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                        <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                        <li><a href="#"><i class="icon-heart"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_info">
                                <h6 class="product_title"><a href="shop-product-detail.php">Red & Black Headphone </a></h6>
                                <div class="product_price">
                                    <span class="price">$45.00 </span>
                                    <del>$55.25 </del>
                                    <div class="on_sale">
                                        <span>35% Off </span>
                                    </div>
                                </div>
                                <div class="rating_wrap">
                                    <div class="rating">
                                        <div class="product_rate" style="width:80%"></div>
                                    </div>
                                    <span class="rating_num">(21) </span>
                                </div>
                                <div class="pr_desc">
                                    <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                </div>
                            </div>
                        </div>
                     </div>
                     <div class="col-6 col-sm-6 col-md-4 col-lg-3">
                        <div class="product_wrap">
                            <div class="product_img">
                                <a href="shop-product-detail.php">
                                    <img src="assets/images/el_img1.jpg" alt="el_img1" />
                                    <img class="product_hover_img" src="assets/images/el_hover_img1.jpg" alt="el_hover_img1" />
                                </a>
                                <div class="product_action_box">
                                    <ul class="list_none pr_action_btn">
                                        <li class="add-to-cart"><a href="#"><i class="icon-basket-loaded"></i> Add To Cart </a></li>
                                        <li><a href="#" class="popup-ajax"><i class="icon-shuffle"></i></a></li>
                                        <li><a  title="Quick View" href="#" class="popup-ajax quickview"><i class="icon-magnifier-add"></i></a></li>
                                        <li><a href="#"><i class="icon-heart"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_info">
                                <h6 class="product_title"><a href="shop-product-detail.php">Red & Black Headphone </a></h6>
                                <div class="product_price">
                                    <span class="price">$45.00 </span>
                                    <del>$55.25 </del>
                                    <div class="on_sale">
                                        <span>35% Off </span>
                                    </div>
                                </div>
                                <div class="rating_wrap">
                                    <div class="rating">
                                        <div class="product_rate" style="width:80%"></div>
                                    </div>
                                    <span class="rating_num">(21) </span>
                                </div>
                                <div class="pr_desc">
                                    <p>Lorem ipsum dolor sit ____, consectetur adipiscing elit. Phasellus _______ massa enim. Nullam id ______ nunc id varius nunc. </p>
                                </div>
                            </div>
                        </div>
                     </div>


                 </div>
        	 </div>
             <div class="col-xl-3">
                <div class="sale-banner_new mb-3 mb-md-4">
                	 <a class="hover_effect1" href="#">
                		 <img src="assets/images/cmsbanner.jpg" alt="shop_banner_img7">
                     </a>
                 </div>

                 <div class="sale-banner_new mb-3 mb-md-4">
                	 <a class="hover_effect1" href="#">
                		 <img src="assets/images/cmsbanner2.jpg" alt="shop_banner_img7">
                     </a>
                 </div>


             </div>
         </div>
     </div>
 </div>
 <!-- END SECTION SHOP -->










 <?php include_once('./inc/footer.php')?>